cat 01/mr.data | 01/map.py | sort | 01/reduce.py
cat 02/mr.data | 02/map.py | sort | 02/reduce.py
cat 03/mr.data | 03/map.py | sort | 03/reduce.py
cat 04/mr.data | 04/map.py | sort | 04/reduce.py
cat 05/mr.data | 05/map.py | sort | 05/reduce.py